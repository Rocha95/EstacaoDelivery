import path from 'node:path'
import { fileURLToPath } from 'node:url'
import dotenv from 'dotenv'
import { createApp } from './app.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
dotenv.config({ path: path.resolve(__dirname, '../.env') })
dotenv.config()

const PORT = process.env.PORT || 3334
const app = createApp()

app.listen(PORT, () => {
  console.log(`API rodando em http://localhost:${PORT}/api`)
})
