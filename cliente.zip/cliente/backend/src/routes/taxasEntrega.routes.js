import { Router } from 'express'
import * as controller from '../controllers/taxasEntrega.controller.js'
import { asyncHandler } from '../utils/asyncHandler.js'
import { autenticar } from '../middlewares/auth.js'

const router = Router()
router.use(autenticar)
router.get('/calcular', asyncHandler(controller.calcular))
export default router
