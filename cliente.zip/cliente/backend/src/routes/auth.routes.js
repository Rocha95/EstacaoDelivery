import { Router } from 'express'
import * as controller from '../controllers/auth.controller.js'
import { asyncHandler } from '../utils/asyncHandler.js'
import { autenticar } from '../middlewares/auth.js'

const router = Router()

router.post('/register', asyncHandler(controller.cadastrar))
router.post('/login', asyncHandler(controller.entrar))
router.post('/cadastrar', asyncHandler(controller.cadastrar))
router.post('/entrar', asyncHandler(controller.entrar))
router.get('/me', autenticar, asyncHandler(controller.perfil))

export default router
