import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import { prisma } from '../lib/prisma.js'
import { ApiError } from '../utils/ApiError.js'

const SELECT_PUBLICO = {
  id: true,
  nome: true,
  telefone: true,
  email: true,
  tipo: true,
  criadoEm: true,
}

const JWT_SECRET = process.env.JWT_SECRET || 'secret_key_delivery_app'

function gerarToken(usuario) {
  return jwt.sign({ id: usuario.id, tipo: usuario.tipo }, JWT_SECRET, { expiresIn: '7d' })
}

function normalizarTelefone(telefone) {
  return String(telefone ?? '').trim()
}

export async function cadastrar(req, res) {
  const nome = String(req.body.nome ?? '').trim()
  const telefone = normalizarTelefone(req.body.telefone)
  const senha = String(req.body.senha ?? '')
  const email = req.body.email ? String(req.body.email).trim().toLowerCase() : null

  if (nome.length < 2 || !telefone || senha.length < 6) {
    throw new ApiError(400, 'Informe nome, celular e uma senha com pelo menos 6 caracteres.')
  }

  const usuarioExiste = await prisma.usuario.findFirst({ where: { telefone } })
  if (usuarioExiste) throw new ApiError(409, 'Este número de celular já está cadastrado.')

  if (email) {
    const emailExiste = await prisma.usuario.findUnique({ where: { email } })
    if (emailExiste) throw new ApiError(409, 'Este e-mail já está cadastrado.')
  }

  const senhaHash = await bcrypt.hash(senha, 10)
  const usuario = await prisma.usuario.create({
    data: { nome, telefone, email, senhaHash, tipo: 'CLIENTE' },
    select: SELECT_PUBLICO,
  })

  res.status(201).json({
    usuario,
    token: gerarToken(usuario),
  })
}

export async function entrar(req, res) {
  const telefone = normalizarTelefone(req.body.telefone)
  const senha = String(req.body.senha ?? '')

  if (!telefone || !senha) throw new ApiError(400, 'Informe celular e senha.')

  const usuario = await prisma.usuario.findFirst({
    where: { telefone, tipo: 'CLIENTE' },
  })

  if (!usuario || !usuario.ativo) throw new ApiError(401, 'Celular ou senha inválidos.')

  const senhaConfere = await bcrypt.compare(senha, usuario.senhaHash)
  if (!senhaConfere) throw new ApiError(401, 'Celular ou senha inválidos.')

  const { senhaHash, ...usuarioSemSenha } = usuario
  res.json({ usuario: usuarioSemSenha, token: gerarToken(usuario) })
}

export async function perfil(req, res) {
  res.json(req.usuario)
}
