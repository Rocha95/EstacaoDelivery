import { prisma } from '../lib/prisma.js'
import { ApiError } from '../utils/ApiError.js'
import { geocodificarEndereco } from '../utils/geocoding.js'

export async function listar(req, res) {
  const enderecos = await prisma.endereco.findMany({
    where: { usuarioId: req.usuario.id },
    orderBy: { criadoEm: 'desc' },
  })
  res.json(enderecos)
}

export async function criar(req, res) {
  const { apelido, rua, numero, complemento, bairro, cidade, estado, cep } = req.body

  if (!rua?.trim() || !bairro?.trim()) {
    throw new ApiError(400, 'Informe rua e bairro.')
  }

  const coordenadas = await geocodificarEndereco({ rua, numero, bairro, cidade, estado, cep })

  const endereco = await prisma.endereco.create({
    data: {
      usuarioId: req.usuario.id,
      apelido: apelido?.trim() || 'Endereço',
      rua: rua.trim(),
      numero: numero?.trim() || null,
      complemento: complemento?.trim() || null,
      bairro: bairro.trim(),
      cidade: cidade?.trim() || '',
      estado: estado?.trim() || '',
      cep: cep?.trim() || null,
      latitude: coordenadas.latitude,
      longitude: coordenadas.longitude,
      distanciaKm: null,
    },
  })

  res.status(201).json(endereco)
}

export async function remover(req, res) {
  const endereco = await prisma.endereco.findFirst({
    where: { id: req.params.id, usuarioId: req.usuario.id },
    select: { id: true },
  })
  if (!endereco) throw new ApiError(404, 'Endereço não encontrado.')

  await prisma.endereco.delete({ where: { id: endereco.id } })
  res.status(204).send()
}
