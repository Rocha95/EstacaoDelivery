export const API_URL = (import.meta.env.VITE_API_URL || 'http://localhost:3334').replace(/\/$/, '')

export function getImagemUrl(caminhoOuUrl) {
  if (!caminhoOuUrl) return null
  if (/^https?:\/\//i.test(caminhoOuUrl)) return caminhoOuUrl
  return `${API_URL}${caminhoOuUrl.startsWith('/') ? '' : '/'}${caminhoOuUrl}`
}

async function request(endpoint, options = {}) {
  const token = localStorage.getItem('token')
  const headers = {
    Accept: 'application/json',
    ...(options.body !== undefined && { 'Content-Type': 'application/json' }),
    ...(token && { Authorization: `Bearer ${token}` }),
    ...(options.headers || {}),
  }

  let res
  try {
    res = await fetch(`${API_URL}${endpoint}`, { ...options, headers })
  } catch {
    throw new Error('Servidor indisponível. Verifique se o backend do cliente está rodando na porta 3334.')
  }

  const contentType = res.headers.get('content-type') || ''
  const data = contentType.includes('application/json')
    ? await res.json().catch(() => ({}))
    : await res.text().catch(() => '')

  if (!res.ok) {
    const message = data?.erro || data?.message || data?.error || `Erro na requisição (${res.status}).`
    if (res.status === 401) {
      localStorage.removeItem('token')
      localStorage.removeItem('usuario')
    }
    throw new Error(message)
  }

  return data
}

export const authApi = {
  login: (dados) => request('/api/auth/login', { method: 'POST', body: JSON.stringify(dados) }),
  register: (dados) => request('/api/auth/register', { method: 'POST', body: JSON.stringify(dados) }),
  me: () => request('/api/auth/me'),
}

export const buscarConfiguracao = () => request('/api/configuracao')
export const buscarHorarios = () => request('/api/horarios')
export const buscarCategorias = () => request('/api/categorias')
export const buscarProdutos = (categoriaId) =>
  request(`/api/produtos${categoriaId ? `?categoriaId=${encodeURIComponent(categoriaId)}` : ''}`)
export const buscarProdutoPorId = (id) => request(`/api/produtos/${encodeURIComponent(id)}`)
export const buscarCombos = () => request('/api/combos')

export const validarCupom = (codigo, subtotal) =>
  request('/api/cupons/validar', {
    method: 'POST',
    body: JSON.stringify({ codigo, subtotal }),
  })

export const calcularTaxaEntrega = (enderecoId) =>
  request(`/api/taxas-entrega/calcular?enderecoId=${encodeURIComponent(enderecoId)}`)
export const calcularRotaEndereco = (enderecoId) =>
  request(`/api/rotas/endereco/${encodeURIComponent(enderecoId)}`)

export const buscarPedidos = () => request('/api/pedidos')
export const buscarPedidoPorId = (id) => request(`/api/pedidos/${encodeURIComponent(id)}`)

export const criarPedido = (dadosPedido) =>
  request('/api/pedidos', { method: 'POST', body: JSON.stringify(dadosPedido) })

export const buscarEnderecos = () => request('/api/enderecos')
export const criarEndereco = (dadosEndereco) =>
  request('/api/enderecos', { method: 'POST', body: JSON.stringify(dadosEndereco) })
export const deletarEndereco = (id) =>
  request(`/api/enderecos/${encodeURIComponent(id)}`, { method: 'DELETE' })
