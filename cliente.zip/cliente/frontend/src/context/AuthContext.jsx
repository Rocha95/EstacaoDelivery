import { createContext, useContext, useState } from 'react'
import { authApi } from '../services/api'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [usuario, setUsuario] = useState(() => {
    try {
      const salvo = localStorage.getItem('usuario')
      return salvo ? JSON.parse(salvo) : null
    } catch {
      localStorage.removeItem('usuario')
      return null
    }
  })

  const entrar = (dadosUsuario, token) => {
    setUsuario(dadosUsuario)
    localStorage.setItem('usuario', JSON.stringify(dadosUsuario))
    if (token) localStorage.setItem('token', token)
  }

  const sair = () => {
    setUsuario(null)
    localStorage.removeItem('usuario')
    localStorage.removeItem('token')
  }

  const atualizarUsuario = (dados) => {
    setUsuario(dados)
    localStorage.setItem('usuario', JSON.stringify(dados))
  }

  return (
    <AuthContext.Provider value={{ usuario, entrar, sair, atualizarUsuario }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth precisa estar dentro de <AuthProvider>')
  return context
}
