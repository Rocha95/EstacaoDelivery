import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useCart } from '../context/CartContext'
import { buscarConfiguracao, buscarHorarios } from '../services/api'

export default function StoreHeader() {
  const navigate = useNavigate()
  const { quantidadeTotal } = useCart()
  const [config, setConfig] = useState(null)
  const [aberto, setAberto] = useState(false)

  useEffect(() => {
    Promise.all([buscarConfiguracao(), buscarHorarios()])
      .then(([c, horarios]) => {
        setConfig(c)
        const agora = new Date()
        const dia = agora.getDay()
        const minuto = agora.getHours() * 60 + agora.getMinutes()
        const h = horarios.find((x) => x.diaSemana === dia && x.ativo)
        if (h) {
          const [hi, mi] = h.abre.split(':').map(Number)
          const [hf, mf] = h.fecha.split(':').map(Number)
          const inicio = hi * 60 + mi
          const fim = hf * 60 + mf
          setAberto(inicio <= fim ? minuto >= inicio && minuto <= fim : minuto >= inicio || minuto <= fim)
        }
      })
      .catch(() => {})
  }, [])

  return (
    <div className="store-header">
      <div className="row">
        <div>
          <div className="mark">#ESTAÇÃO</div>
          <div className="store-name">{config?.nomeEstabelecimento || 'Estação Delivery'}</div>
          <div className="store-meta">{config?.endereco || 'Delivery e retirada'}</div>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <span className={`header-pill ${aberto ? 'open' : ''}`}><span className="dot" />{aberto ? 'Aberto' : 'Fechado'}</span>
          <button className="icon-btn" onClick={() => navigate('/carrinho')}>
            🛒{quantidadeTotal > 0 && <span className="cart-badge">{quantidadeTotal}</span>}
          </button>
        </div>
      </div>
    </div>
  )
}
