import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import StoreHeader from '../components/StoreHeader'
import BottomNav from '../components/BottomNav'
import BottomCartBar from '../components/BottomCartBar'
import { buscarProdutos, getImagemUrl } from '../services/api'

export default function Home() {
  const navigate = useNavigate()
  const [produtos, setProdutos] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [categoriaAtiva, setCategoriaAtiva] = useState('Todas')
  const [errosImagem, setErrosImagem] = useState({})

  useEffect(() => {
    buscarProdutos()
      .then((data) => setProdutos(Array.isArray(data) ? data : []))
      .catch((err) => setError(err.message || 'Não foi possível carregar o cardápio.'))
      .finally(() => setLoading(false))
  }, [])

  const categorias = useMemo(
    () => Array.from(new Set(produtos.map((p) => p.categoria?.nome || p.categoriaNome).filter(Boolean))),
    [produtos]
  )

  const visiveis = useMemo(() => {
    if (categoriaAtiva === 'Todas') return produtos
    return produtos.filter((p) => (p.categoria?.nome || p.categoriaNome) === categoriaAtiva)
  }, [categoriaAtiva, produtos])

  return (
    <div className="app-frame">
      <StoreHeader />
      <div className="category-tabs">
        {['Todas', ...categorias].map((c) => (
          <button key={c} className={`category-pill ${categoriaAtiva === c ? 'active' : ''}`} onClick={() => setCategoriaAtiva(c)}>{c}</button>
        ))}
      </div>
      <div className="content">
        <div className="section-title">{categoriaAtiva === 'Todas' ? 'Cardápio completo' : categoriaAtiva}</div>
        {loading && <div className="empty-state" style={{ paddingTop: 40 }}>Carregando cardápio...</div>}
        {error && <div className="empty-state" style={{ paddingTop: 40, color: '#d32f2f' }}>{error}</div>}
        {!loading && !error && (
          <div className="product-grid">
            {visiveis.map((p) => {
              const idProduto = p.id
              const src = getImagemUrl(p.imagemUrl)
              return (
                <div key={idProduto} className="product-card" onClick={() => navigate(`/produto/${idProduto}`)}>
                  <div className="product-thumb" style={{ overflow: 'hidden' }}>
                    {src && !errosImagem[idProduto]
                      ? <img src={src} alt={p.nome} onError={() => setErrosImagem((prev) => ({ ...prev, [idProduto]: true }))} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                      : p.emoji || '🍽️'}
                  </div>
                  <div className="product-info">
                    <div className="name">{p.nome}</div>
                    <div className="row"><span className="price">R$ {Number(p.preco).toFixed(2)}</span><span className="add-btn">+</span></div>
                  </div>
                </div>
              )
            })}
          </div>
        )}
        {!loading && !error && visiveis.length === 0 && <div className="empty-state">Nenhum produto disponível.</div>}
      </div>
      <BottomCartBar />
      <BottomNav />
    </div>
  )
}
