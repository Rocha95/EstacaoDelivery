import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import TopNavBack from '../components/TopNavBack'
import { buscarPedidoPorId } from '../services/api'

const ETAPAS = [
  ['RECEBIDO', 'Pedido recebido', '🧾'],
  ['EM_PRODUCAO', 'Em produção', '👨‍🍳'],
  ['SAIU_PARA_ENTREGA', 'Saiu para entrega', '🛵'],
  ['FINALIZADO', 'Entregue', '🎉'],
]

export default function Acompanhamento() {
  const { id } = useParams()
  const [pedido, setPedido] = useState(null)
  const [erro, setErro] = useState('')

  useEffect(() => {
    let ativo = true
    const carregar = () => buscarPedidoPorId(id).then((p) => ativo && setPedido(p)).catch((e) => ativo && setErro(e.message))
    carregar()
    const timer = setInterval(carregar, 15000)
    return () => { ativo = false; clearInterval(timer) }
  }, [id])

  if (erro) return <div className="app-frame"><TopNavBack title="Pedido" to="/historico" /><div className="content">{erro}</div></div>
  if (!pedido) return <div className="app-frame"><TopNavBack title="Pedido" to="/historico" /><div className="content">Carregando pedido...</div></div>

  const statusIndex = ETAPAS.findIndex(([status]) => status === pedido.status)

  return (
    <div className="app-frame">
      <TopNavBack title={`Pedido #${pedido.numero}`} to="/historico" />
      <div className="content">
        <div className="card" style={{ marginBottom: 18, textAlign: 'center' }}>
          <div style={{ fontSize: 12.5, color: '#8A867C' }}>Status atual</div>
          <div style={{ fontSize: 20, fontWeight: 800 }}>{pedido.status === 'CANCELADO' ? 'Pedido cancelado' : ETAPAS[Math.max(statusIndex, 0)]?.[1]}</div>
          <div style={{ fontSize: 12, color: '#8A867C', marginTop: 5 }}>Total: R$ {Number(pedido.total).toFixed(2)}</div>
        </div>

        {pedido.status !== 'CANCELADO' && (
          <div className="tracker">
            {ETAPAS.map(([status, label, icon], i) => (
              <div key={status} className={`tracker-step ${i < statusIndex ? 'done' : i === statusIndex ? 'current' : ''}`}>
                <div className="tracker-dot">{i <= statusIndex ? icon : i + 1}</div>
                <div><div className="label">{label}</div></div>
              </div>
            ))}
          </div>
        )}

        <div className="section-title">Itens do pedido</div>
        <div className="card">
          {pedido.itens.map((item) => (
            <div className="list-row" key={item.id}>
              <div className="list-thumb">{item.produto?.emoji || '🍽️'}</div>
              <div style={{ flex: 1 }}>
                <div>{item.quantidade}x {item.nome}</div>
                {item.adicionais?.length > 0 && <div style={{ fontSize: 11.5, color: '#8A867C' }}>{item.adicionais.map((a) => a.nome).join(', ')}</div>}
              </div>
              <div className="money">R$ {(Number(item.precoUnitario) * item.quantidade).toFixed(2)}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
